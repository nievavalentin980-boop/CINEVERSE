CINEVERSE - Proyecto Android

Este ZIP contiene el PROYECTO FUENTE Android, no un APK ya compilado.

Para generar el APK:
1. Subí esta carpeta a un repositorio GitHub.
2. Abrí la pestaña Actions.
3. Ejecutá el workflow "Construir APK Android".
4. Descargá el artefacto CINEVERSE-debug-apk.
5. En tu Samsung, abrí el APK descargado y autorizá la instalación si Android lo solicita.

También podés abrir el proyecto en Android Studio y ejecutar:
gradle assembleDebug

El APK de depuración se genera en:
app/build/outputs/apk/debug/app-debug.apk

La app incluye un catálogo de demostración. La integración TMDB y la reproducción autorizada todavía no están conectadas.
No publiques claves privadas de API dentro de archivos JavaScript ni en repositorios públicos.
