// Catálogo de muestra. Más adelante se puede conectar con TMDB usando una clave propia.
const peliculas=[
 {titulo:"Interestelar",anio:2014,tipo:"Película",imagen:"https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg"},
 {titulo:"Batman",anio:2022,tipo:"Película",imagen:"https://image.tmdb.org/t/p/w500/74xTEgt7R36Fpooo50r9T25onhq.jpg"},
 {titulo:"Avatar",anio:2009,tipo:"Película",imagen:"https://image.tmdb.org/t/p/w500/kyeqWdyUXW608qlYkRqosgbbJyK.jpg"},
 {titulo:"Joker",anio:2019,tipo:"Película",imagen:"https://image.tmdb.org/t/p/w500/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg"}
];
const series=[
 {titulo:"Stranger Things",anio:2016,tipo:"Serie",imagen:"https://image.tmdb.org/t/p/w500/x2LSRK2Cm7MZhjluni1msVJ3wDF.jpg"},
 {titulo:"Wednesday",anio:2022,tipo:"Serie",imagen:"https://image.tmdb.org/t/p/w500/9PFonBhy4cQy7Jz20NpMygczOkv.jpg"},
 {titulo:"Breaking Bad",anio:2008,tipo:"Serie",imagen:"https://image.tmdb.org/t/p/w500/ztkUQFLlC19CCMYHW9o1zWhJRNq.jpg"}
];
function mostrar(items,id){
 const cont=document.getElementById(id);cont.innerHTML="";
 if(!items.length){cont.innerHTML='<p>No se encontraron títulos.</p>';return;}
 items.forEach(p=>{
  const card=document.createElement("article");card.className="card";
  const img=document.createElement("img");img.src=p.imagen;img.alt=p.titulo;img.loading="lazy";
  const info=document.createElement("div");info.className="info";
  const title=document.createElement("h3");title.textContent=p.titulo;
  const meta=document.createElement("p");meta.textContent=p.tipo+" · "+p.anio;
  info.append(title,meta);card.append(img,info);cont.append(card);
 });
}
function render(q=""){
 const s=q.toLowerCase();
 mostrar(peliculas.filter(p=>p.titulo.toLowerCase().includes(s)),"peliculas-lista");
 mostrar(series.filter(p=>p.titulo.toLowerCase().includes(s)),"series-lista");
}
document.getElementById("busqueda").addEventListener("input",e=>render(e.target.value));
render();
